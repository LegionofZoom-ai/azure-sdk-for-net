SANITISED SYNTHETIC SAMPLE

This directory and its companion sample-sanitised-evidence.tar.gz demonstrate
the evidence layout. They are not runner observations and must not be cited as
research evidence. Placeholder values are intentional.
