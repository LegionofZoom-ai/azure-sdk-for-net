#!/usr/bin/env node
'use strict';

// Dependency-free Docker Engine API client for Runner Boundary Audit v3.
const http = require('http');
const fs = require('fs');
const crypto = require('crypto');
const socketPath = process.env.DOCKER_SOCK || '/var/run/docker.sock';
const mode = process.argv[2];
const argument = process.argv[3];
const runId = process.env.RBA_RUN_ID || 'unknown';
const image = process.env.RBA_TEST_IMAGE || 'node:18-bullseye';
const runLabel = 'org.runner-boundary-audit.run=' + runId;

function request(method, path, body, binary) {
  return new Promise(function (resolve, reject) {
    const payload = body === undefined ? undefined : JSON.stringify(body);
    const headers = payload ? {'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload)} : {};
    const req = http.request({socketPath: socketPath, method: method, path: path, headers: headers}, function (res) {
      const chunks = [];
      let size = 0;
      res.on('data', function (chunk) {
        size += chunk.length;
        if (size > 2000000) req.destroy(new Error('Docker response exceeded 2 MB'));
        else chunks.push(chunk);
      });
      res.on('end', function () {
        const data = Buffer.concat(chunks);
        const text = data.toString('utf8');
        let json = null;
        if (!binary) {
          try { json = JSON.parse(text); } catch (_) {}
        }
        resolve({status: res.statusCode, json: json, body: binary ? data : text});
      });
    });
    req.on('error', reject);
    req.setTimeout(10000, function () { req.destroy(new Error('Docker API timeout')); });
    req.end(payload);
  });
}

function check(response, label, accepted) {
  accepted = accepted || [200, 201, 204];
  if (accepted.indexOf(response.status) === -1) {
    const detail = String((response.json && response.json.message) || response.body || '').slice(0, 240);
    throw new Error(label + ' returned HTTP ' + response.status + ': ' + detail);
  }
  return response.json;
}

function apiVersion(value) {
  const match = String(value || '1.24').match(/^(\d+)\.(\d+)/);
  if (!match) return 'v1.24';
  return 'v' + Number(match[1]) + '.' + Math.min(Number(match[2]), 48);
}

async function api() {
  const version = check(await request('GET', '/version'), 'version', [200]);
  return {base: '/' + apiVersion(version.ApiVersion), version: version};
}

function cleanText(value) {
  return String(value).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').slice(0, 16384);
}

function dockerStream(buffer) {
  let stdout = '';
  let stderr = '';
  let position = 0;
  while (position + 8 <= buffer.length) {
    const stream = buffer[position];
    const length = buffer.readUInt32BE(position + 4);
    if (position + 8 + length > buffer.length) break;
    const value = buffer.subarray(position + 8, position + 8 + length).toString('utf8');
    if (stream === 2) stderr += value; else stdout += value;
    position += 8 + length;
  }
  if (position === 0 && buffer.length) stdout = buffer.toString('utf8');
  return {stdout: cleanText(stdout), stderr: cleanText(stderr)};
}

async function execIn(base, id, command) {
  const created = check(await request('POST', base + '/containers/' + id + '/exec',
    {AttachStdout: true, AttachStderr: true, Tty: false, Cmd: command}), 'exec create');
  const started = await request('POST', base + '/exec/' + created.Id + '/start',
    {Detach: false, Tty: false}, true);
  if (started.status !== 200) throw new Error('exec start returned HTTP ' + started.status);
  const output = dockerStream(started.body);
  const inspected = check(await request('GET', base + '/exec/' + created.Id + '/json'), 'exec inspect', [200]);
  return {stdout: output.stdout, stderr: output.stderr, exitCode: inspected.ExitCode, running: inspected.Running};
}

async function remove(base, id) {
  try { return (await request('DELETE', base + '/containers/' + id + '?force=true&v=true')).status; }
  catch (_) { return 0; }
}

function isolatedConfig() {
  return {
    Image: image, Cmd: ['/bin/sh', '-c', 'sleep 30'], Tty: false,
    Labels: {'org.runner-boundary-audit': 'true', 'org.runner-boundary-audit.run': runId},
    HostConfig: {
      Privileged: false, ReadonlyRootfs: true, CapDrop: ['ALL'], NetworkMode: 'none',
      Tmpfs: {'/tmp': 'rw,nosuid,nodev,size=8m,mode=1777'},
      SecurityOpt: ['no-new-privileges:true'], AutoRemove: false
    }
  };
}

async function withContainer(config, operation) {
  const connection = await api();
  let id;
  try {
    const name = 'rba-' + mode + '-' + process.pid + '-' + crypto.randomBytes(3).toString('hex');
    id = check(await request('POST', connection.base + '/containers/create?name=' + encodeURIComponent(name), config), 'create').Id;
    check(await request('POST', connection.base + '/containers/' + id + '/start'), 'start', [204, 304]);
    const inspected = check(await request('GET', connection.base + '/containers/' + id + '/json'), 'inspect', [200]);
    return await operation(connection.base, id, inspected);
  } finally {
    if (id) process.stderr.write('cleanup HTTP ' + await remove(connection.base, id) + '\n');
  }
}

function namespaceLinks() {
  const result = {};
  for (const name of ['cgroup', 'ipc', 'mnt', 'net', 'pid', 'pid_for_children', 'time', 'user', 'uts']) {
    try { result[name] = fs.readlinkSync('/proc/self/ns/' + name); } catch (_) {}
  }
  return result;
}

async function main() {
  if (mode === 'probe') {
    const ping = await request('GET', '/_ping');
    const connection = await api();
    const info = check(await request('GET', connection.base + '/info'), 'info', [200]);
    console.log(JSON.stringify({
      socketAccessible: ping.status === 200, pingStatus: ping.status,
      serverVersion: connection.version.Version || null, apiVersion: connection.version.ApiVersion || null,
      os: connection.version.Os || null, arch: connection.version.Arch || null,
      kernelVersion: connection.version.KernelVersion || null,
      rootless: (info.SecurityOptions || []).some(function (x) { return x.includes('rootless'); }),
      securityOptions: info.SecurityOptions || [], liveRestore: info.LiveRestoreEnabled === undefined ? null : info.LiveRestoreEnabled,
      containerCount: Number.isInteger(info.Containers) ? info.Containers : null
    }, null, 2));
    return;
  }
  if (mode === 'containers') {
    const connection = await api();
    const list = check(await request('GET', connection.base + '/containers/json?all=true'), 'containers', [200]);
    console.log(JSON.stringify(list.map(function (item) {
      return {idHash: crypto.createHash('sha256').update(item.Id).digest('hex').slice(0, 16),
        state: item.State, imageReferenceHash: crypto.createHash('sha256').update(String(item.Image)).digest('hex').slice(0, 16), created: item.Created,
        labelsPresent: Object.keys(item.Labels || {}).length > 0};
    }), null, 2));
    return;
  }
  if (mode === 'inspect') {
    if (!argument || !/^[a-f0-9]{12,64}$/i.test(argument)) throw new Error('inspect requires a container ID');
    const connection = await api();
    const item = check(await request('GET', connection.base + '/containers/' + argument + '/json'), 'inspect', [200]);
    console.log(JSON.stringify({
      id: item.Id.slice(0, 12), created: item.Created,
      state: {status: item.State && item.State.Status, running: item.State && item.State.Running, exitCode: item.State && item.State.ExitCode},
      image: item.Config && item.Config.Image, privileged: item.HostConfig && item.HostConfig.Privileged,
      readonlyRootfs: item.HostConfig && item.HostConfig.ReadonlyRootfs,
      networkMode: item.HostConfig && item.HostConfig.NetworkMode, pidMode: item.HostConfig && item.HostConfig.PidMode,
      bindCount: ((item.HostConfig && item.HostConfig.Binds) || []).length,
      securityOpt: (item.HostConfig && item.HostConfig.SecurityOpt) || []
    }, null, 2));
    return;
  }
  if (mode === 'lifecycle') {
    const result = await withContainer(isolatedConfig(), async function (base, id, inspected) {
      const execution = await execIn(base, id, ['/bin/sh', '-c', 'printf "command_execution=confirmed\\n"; id -u; uname -s']);
      if (execution.exitCode !== 0) throw new Error('exec exit ' + execution.exitCode);
      return {
        created: true, started: inspected.State.Running === true, inspected: true, id: id.slice(0, 12),
        configuration: {
          privileged: inspected.HostConfig.Privileged, readonlyRootfs: inspected.HostConfig.ReadonlyRootfs,
          capDrop: inspected.HostConfig.CapDrop || [], networkMode: inspected.HostConfig.NetworkMode,
          binds: inspected.HostConfig.Binds || [], securityOpt: inspected.HostConfig.SecurityOpt || []
        }, exec: execution, cleanup: 'attempted in finally'
      };
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (mode === 'scratch') {
    const result = await withContainer(isolatedConfig(), async function (base, id) {
      const command = 'set -eu; f=/tmp/rba-scratch; printf RBA_TEST_OK >"$f"; value=$(cat "$f"); rm -f "$f"; printf "value=%s\\nresidue=%s\\n" "$value" "$(test -e "$f" && echo yes || echo no)"';
      const execution = await execIn(base, id, ['/bin/sh', '-c', command]);
      if (execution.exitCode !== 0 || !execution.stdout.includes('value=RBA_TEST_OK') || !execution.stdout.includes('residue=no')) throw new Error('scratch assertion failed');
      return {scratchLocation: 'container-only tmpfs', writeReadDeleteVerified: true, exec: execution};
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (mode === 'namespace-compare') {
    const jobNamespaces = namespaceLinks();
    const config = isolatedConfig();
    config.HostConfig.PidMode = 'host';
    const result = await withContainer(config, async function (base, id, inspected) {
      const command = 'for n in cgroup ipc mnt net pid pid_for_children time user uts; do p=/proc/self/ns/$n; test -e "$p" && printf "%s %s\\n" "$n" "$(readlink "$p")"; done; printf "host_pid1_pid %s\\n" "$(readlink /proc/1/ns/pid 2>/dev/null || echo unavailable)"';
      const execution = await execIn(base, id, ['/bin/sh', '-c', command]);
      if (execution.exitCode !== 0) throw new Error('namespace read failed');
      return {jobContainerNamespaces: jobNamespaces, comparisonContainerPidMode: inspected.HostConfig.PidMode,
        comparisonOutput: execution.stdout, note: 'Only namespace inode identifiers were read; no host process command lines were collected.'};
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (mode === 'host-mount') {
    const config = isolatedConfig();
    config.HostConfig.Binds = ['/:/rba-host:ro'];
    const result = await withContainer(config, async function (base, id, inspected) {
      const command = 'set -eu; stat -f -c "fs_type=%T fs_id=%i block_size=%S" /rba-host; for p in etc/os-release etc/machine-id var/lib/cloud; do test -e "/rba-host/$p" && printf "marker_present=%s\\n" "$p"; done';
      const execution = await execIn(base, id, ['/bin/sh', '-c', command]);
      if (execution.exitCode !== 0) throw new Error('read-only host mount failed');
      return {binds: inspected.HostConfig.Binds, readonly: true, exec: execution,
        note: 'Only filesystem metadata and marker presence were collected; contents were not read.'};
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (mode === 'host-write') {
    const source = process.env.RBA_LAB_HOST_PATH || '/tmp';
    if (!source.startsWith('/') || source.includes(':')) throw new Error('RBA_LAB_HOST_PATH must be absolute and contain no colon');
    const token = ('.rba-write-' + runId + '-' + crypto.randomBytes(4).toString('hex')).replace(/[^A-Za-z0-9_.-]/g, '_');
    const config = isolatedConfig();
    config.HostConfig.Binds = [source + ':/rba-host:rw'];
    const result = await withContainer(config, async function (base, id, inspected) {
      const command = 'set -eu; f=/rba-host/' + token + '; trap \'rm -f "$f"\' EXIT HUP INT TERM; printf RBA_WRITE_TEST >"$f"; test "$(cat "$f")" = RBA_WRITE_TEST; rm -f "$f"; test ! -e "$f"; printf "write_read_delete=confirmed\\nresidue=no\\n"';
      const execution = await execIn(base, id, ['/bin/sh', '-c', command]);
      if (execution.exitCode !== 0 || !execution.stdout.includes('residue=no')) throw new Error('host write assessment failed');
      return {source: source, binds: inspected.HostConfig.Binds, uniqueFilename: token, writeReadDeleteVerified: true, exec: execution};
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (mode === 'host-namespace') {
    const config = isolatedConfig();
    config.HostConfig.Privileged = true;
    config.HostConfig.CapDrop = [];
    config.HostConfig.PidMode = 'host';
    config.HostConfig.SecurityOpt = [];
    const result = await withContainer(config, async function (base, id, inspected) {
      const command = 'set -eu; command -v nsenter >/dev/null; nsenter -t 1 -m -u -i -n -p -- /bin/sh -c \'printf "host_namespace_execution=confirmed\\n"; readlink /proc/self/ns/mnt /proc/self/ns/pid /proc/self/ns/net /proc/self/ns/uts\'';
      const execution = await execIn(base, id, ['/bin/sh', '-c', command]);
      if (execution.exitCode !== 0 || !execution.stdout.includes('host_namespace_execution=confirmed')) throw new Error('host namespace execution not confirmed');
      return {privileged: inspected.HostConfig.Privileged, pidMode: inspected.HostConfig.PidMode, exec: execution,
        mutation: 'none; identifier commands only'};
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (mode === 'cleanup-run') {
    const connection = await api();
    const filters = encodeURIComponent(JSON.stringify({label: [runLabel]}));
    const list = check(await request('GET', connection.base + '/containers/json?all=true&filters=' + filters), 'cleanup inventory', [200]);
    const removed = [];
    for (const item of list) removed.push({id: item.Id.slice(0, 12), status: await remove(connection.base, item.Id)});
    console.log(JSON.stringify({removed: removed}, null, 2));
    return;
  }
  throw new Error('Unknown mode');
}

main().catch(function (error) {
  console.error('Docker API client: ' + cleanText(error.message));
  process.exitCode = 1;
});
