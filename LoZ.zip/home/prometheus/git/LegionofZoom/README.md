# Runner Boundary Audit v3

Runner Boundary Audit is an evidence-oriented Bash tool for analysing isolation on an authorised GitHub Actions runner or a disposable lab VM. It uses Node 18's built-in HTTP client for Docker's Unix socket; it does not require the Docker CLI, jq, Python, or npm packages.

## Requirements

- Bash 4 or newer
- Node.js 18 or newer
- GNU coreutils and GNU tar 1.34
- curl only when upload is requested
- A locally available node:18-bullseye image for Docker lifecycle tests (override with RBA_TEST_IMAGE)
- Read/write access to /var/run/docker.sock for Docker tests

Run every hosted-safe test:

~~~sh
bash runner-boundary-tui.sh --all --profile hosted
~~~

Run and explicitly upload the sanitised archive:

~~~sh
bash runner-boundary-tui.sh --all --profile hosted --upload
~~~

The upload endpoint is fixed to https://ul.sto.care. The tool uses multipart field file, accepts only a 2xx response, validates that the returned URL is HTTPS on sto.care, and prints that URL plus the local archive SHA-256. No upload occurs without --upload.

Run controlled lab tests only on an authorised disposable VM:

~~~sh
RBA_LAB_HOST_PATH=/tmp bash runner-boundary-tui.sh --all --profile lab --authorize-lab
~~~

Selecting lab without --authorize-lab runs the read-only lab mount check but records host-write and host-namespace execution as BLOCKED. The hosted profile records all three lab-only tests as SKIPPED. This is deliberate and visible in both report formats.

## Test registry and status semantics

The registry contains 16 tests: container/runner identity, capability masks, namespace identity, seccomp/AppArmor/user namespaces, block devices, mount topology, Docker access, sanitised inventory, Docker lifecycle/exec/output, isolated tmpfs write/read/delete, host-versus-container namespace comparison, host-root mount/identification, controlled host write permission, controlled host namespace execution, OIDC presence, and lifecycle evidence.

Every registry entry produces exactly one of:

- PASS: the test completed and recorded an outcome; it is not a security rating.
- FAIL: a negative assertion result (reserved for checks with a defined assertion).
- BLOCKED: a prerequisite or explicit authorization was absent.
- SKIPPED: profile policy prohibited execution.
- ERROR: the test attempted execution but its mechanism failed.

Docker lifecycle and scratch containers are read-only, capability-dropped, networkless, no-new-privileges containers with a private tmpfs. Namespace comparison is the documented exception: it remains unprivileged and read-only but requests host PID mode solely to collect namespace inode identifiers. Host-root bind mounting and privileged namespace entry are lab-only. Every created container carries a run-specific label and is removed in a finally block plus an exit/signal cleanup sweep.

## Evidence

Each run creates:

- evidence.txt: human-readable report
- results.json: machine-readable environment, results, timings, status counts, and interpretation
- results.ndjson: append-only per-test records
- environment.json: allowlisted environment and runner identification
- test-*.txt: individual observed outcomes
- docker-api-client.js: exact client used
- SHA256SUMS: hashes of every included evidence file
- a reproducible-name tar.gz archive with normalized ownership and sorted members

Credential values, private keys, OIDC tokens, environment dumps, process command lines, and host file contents are not collected. Docker responses are projected onto an allowlist of relevant fields. OIDC checks record presence only.

## Interpretation limits

Container UID 0 and broad capabilities describe the job container. Docker daemon control or an eligible host bind mount is separate evidence of runner-host control. Successful nsenter is separate evidence of host namespace execution. None of those observations establishes access outside the allocated runner VM, runner reuse, cross-runner access, or cross-tenant compromise. See [DISCLOSURE-ANALYSIS.md](DISCLOSURE-ANALYSIS.md).

## Tests

~~~sh
bash tests/static.sh
bash tests/hosted-smoke.sh
RBA_DISPOSABLE_LAB=1 bash tests/lab-integration.sh
~~~

The lab integration test refuses to run without RBA_DISPOSABLE_LAB=1 and --authorize-lab is supplied internally. It will create privileged containers briefly and perform one write/read/delete cycle under RBA_LAB_HOST_PATH (default /tmp).
