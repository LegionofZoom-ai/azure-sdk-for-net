#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
bash -n runner-boundary-tui.sh
node --check docker-api-client.js
test "$(grep -o 'TEST_NAMES\[[^]]*\]=' runner-boundary-tui.sh | wc -l)" -eq 16
grep -q -- '--profile hosted' runner-boundary-tui.sh
grep -q -- '--authorize-lab' runner-boundary-tui.sh
grep -q 'cleanup-run' docker-api-client.js
! grep -Eq '(^|[[:space:]])(docker|jq|python)([[:space:]]|$)' runner-boundary-tui.sh docker-api-client.js
bash runner-boundary-tui.sh --help >/dev/null
printf 'static tests: PASS\n'
