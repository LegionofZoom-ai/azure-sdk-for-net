#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
[[ ${RBA_DISPOSABLE_LAB:-} == 1 ]] || {
  echo 'SKIPPED: set RBA_DISPOSABLE_LAB=1 only on an authorised disposable Docker lab'
  exit 0
}
[[ -S ${DOCKER_SOCK:-/var/run/docker.sock} ]] || { echo 'BLOCKED: Docker socket missing' >&2; exit 1; }
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT
RBA_LAB_HOST_PATH=${RBA_LAB_HOST_PATH:-/tmp} bash runner-boundary-tui.sh --all --profile lab --authorize-lab --output-dir "$work/evidence"
RBA_RESULTS="$work/evidence/results.json" node - <<'NODE'
const fs=require('fs');
const result=JSON.parse(fs.readFileSync(process.env.RBA_RESULTS,'utf8'));
if(result.results.length!==16)throw Error('expected all 16 tests');
for(const id of ['host_mount','host_write','host_namespace']){
  const item=result.results.find(function(x){return x.id===id});
  if(!item)throw Error('missing '+id);
  if(item.status==='SKIPPED'||item.status==='BLOCKED')throw Error(id+' did not execute');
}
NODE
printf 'disposable lab integration: PASS\n'
