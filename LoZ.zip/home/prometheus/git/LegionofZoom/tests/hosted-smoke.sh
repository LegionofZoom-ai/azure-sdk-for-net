#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT
DOCKER_SOCK="$work/no-docker.sock" bash runner-boundary-tui.sh --all --profile hosted --output-dir "$work/evidence" >/dev/null
RBA_RESULTS="$work/evidence/results.json" node - <<'NODE'
const fs=require('fs');
const result=JSON.parse(fs.readFileSync(process.env.RBA_RESULTS,'utf8'));
if(result.results.length!==16)throw Error('expected 16 registry results');
for(const item of result.results)if(!['PASS','FAIL','BLOCKED','SKIPPED','ERROR'].includes(item.status))throw Error('bad status');
for(const id of ['host_mount','host_write','host_namespace']){
  const item=result.results.find(function(x){return x.id===id});
  if(!item||item.status!=='SKIPPED')throw Error(id+' was not explicitly skipped');
}
if(result.results.filter(function(x){return x.id.startsWith('docker_')||x.id==='scratch'||x.id==='namespace_compare'}).some(function(x){return x.status!=='BLOCKED'}))throw Error('missing Docker prerequisites not BLOCKED');
NODE
(cd "$work/evidence" && sha256sum -c SHA256SUMS >/dev/null)
test -f "$work/evidence.tar.gz"
printf 'hosted smoke test: PASS\n'
