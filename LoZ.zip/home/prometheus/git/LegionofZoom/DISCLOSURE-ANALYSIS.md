# Disclosure-oriented interpretation

The result status says whether a test ran reliably, not whether an environment is secure.

| Test area | Directly supports | Does not prove |
|---|---|---|
| Identity and capabilities | Job-container UID, kernel view, capability masks | That capabilities apply in host namespaces |
| Namespace and LSM configuration | Namespace inode identities, mappings, seccomp and AppArmor state visible to the process | Host namespace entry or arbitrary host control |
| Devices and mounts | Device nodes and mount metadata exposed to the job | Readability of device contents or another tenant's data |
| Docker access | Whether the Unix socket/API answers and its sanitised daemon configuration | Cross-tenant control |
| Docker lifecycle and scratch | Ability to create, inspect, execute in, capture output from, and delete an isolated container; private tmpfs I/O | Host command execution |
| Namespace comparison | Docker accepted host PID mode and returned namespace identifiers | Host mount/network namespace entry; it executes no host command |
| Host mount (lab) | Docker accepted a read-only bind of slash and exposed filesystem type/marker presence | Write access, persistence, or access beyond that VM |
| Host write (authorised lab) | A unique file could be written, read, deleted, and confirmed absent in the selected host directory | Arbitrary writes everywhere or persistence after VM disposal |
| Host namespace (authorised lab) | A controlled identifier command ran through nsenter in host namespaces | Cross-runner/cross-tenant access |
| OIDC | Request URL/token environment variables are present | Token validity, claims, cloud authorization, or token exfiltration |
| Lifecycle evidence | Boot ID, uptime, PID 1 start ticks, cgroup and kernel values for correlation | That GitHub destroys/reuses the VM or that state persists between jobs |

Claims should therefore be stated in increasing, non-equivalent layers:

1. Container root: directly observed only when uid=0.
2. Runner-host control: supported only by a distinct Docker/host boundary observation.
3. Host namespace execution: supported only by the authorised lab nsenter result.
4. Cross-runner or cross-tenant compromise: outside this audit and never inferred.

Absence of an observation is not proof of an enforced boundary when a test is BLOCKED or SKIPPED. ERROR means the mechanism failed, not that the boundary resisted it.
