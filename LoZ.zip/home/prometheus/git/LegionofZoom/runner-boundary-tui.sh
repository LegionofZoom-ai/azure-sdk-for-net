#!/usr/bin/env bash
# Runner Boundary Audit v3.0 -- evidence-oriented isolation research.
set -Eeuo pipefail
umask 077

VERSION=3.0.0
PROFILE=hosted
DO_ALL=false
DO_UPLOAD=false
LAB_AUTHORIZED=false
OUTPUT_DIR=''
SOCK=${DOCKER_SOCK:-/var/run/docker.sock}
TEST_IMAGE=${RBA_TEST_IMAGE:-node:18-bullseye}
UPLOAD_ENDPOINT=${RBA_UPLOAD_ENDPOINT:-https://ul.sto.care}
RUN_ID="rba-$(date -u +%Y%m%dT%H%M%SZ)-$$"
ARCHIVE=''
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
CLIENT_SOURCE="$SCRIPT_DIR/docker-api-client.js"

usage() {
  cat <<'EOF'
Runner Boundary Audit v3.0
Usage:
  bash runner-boundary-tui.sh --all --profile hosted [--upload] [--output-dir DIR]
  bash runner-boundary-tui.sh --all --profile lab --authorize-lab [--upload]
  bash runner-boundary-tui.sh --bundle [--profile hosted]
  bash runner-boundary-tui.sh

--all              Run every registered test; disallowed tests are recorded SKIPPED.
--profile P         hosted (default) or lab.
--authorize-lab    Confirm an authorised disposable VM; required for write/ns tests.
--upload           Upload the sanitised archive to https://ul.sto.care.
--output-dir DIR   Use a new or empty evidence directory.
--bundle            Compatibility alias for --all.
EOF
}

while (($#)); do
  case $1 in
    --all|--bundle) DO_ALL=true ;;
    --profile) (($# >= 2)) || { echo '--profile needs a value' >&2; exit 2; }; PROFILE=$2; shift ;;
    --authorize-lab) LAB_AUTHORIZED=true ;;
    --upload) DO_UPLOAD=true ;;
    --output-dir) (($# >= 2)) || { echo '--output-dir needs a path' >&2; exit 2; }; OUTPUT_DIR=$2; shift ;;
    --help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
[[ $PROFILE == hosted || $PROFILE == lab ]] || { echo 'Profile must be hosted or lab' >&2; exit 2; }
[[ -f $CLIENT_SOURCE ]] || { echo "Missing Docker API client: $CLIENT_SOURCE" >&2; exit 2; }
command -v node >/dev/null 2>&1 || { echo 'Node.js 18 or newer is required' >&2; exit 2; }

if [[ -n $OUTPUT_DIR ]]; then
  if [[ -e $OUTPUT_DIR && (! -d $OUTPUT_DIR || -n $(find "$OUTPUT_DIR" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)) ]]; then
    echo "Refusing non-empty --output-dir: $OUTPUT_DIR" >&2; exit 2
  fi
  mkdir -p "$OUTPUT_DIR"; BASE=$(cd "$OUTPUT_DIR" && pwd -P)
else
  BASE=${RBA_DIR:-"$PWD/runner-boundary-$RUN_ID"}
  mkdir -p "$BASE"; BASE=$(cd "$BASE" && pwd -P)
fi
REPORT="$BASE/evidence.txt"
RESULTS_NDJSON="$BASE/results.ndjson"
SUMMARY="$BASE/results.json"
ENVIRONMENT="$BASE/environment.json"
HELPER="$BASE/docker-api-client.js"
cp "$CLIENT_SOURCE" "$HELPER"; chmod 700 "$HELPER"; : >"$RESULTS_NDJSON"

cat >"$REPORT" <<EOF
Runner Boundary Audit v$VERSION
Run ID: $RUN_ID
Started UTC: $(date -u +%FT%TZ)
Selected profile: $PROFILE
Lab impact authorized: $LAB_AUTHORIZED
Evidence policy: credentials, tokens, keys, and unrelated file contents are excluded.
Interpretation: container root != runner-host control != host namespace execution != cross-runner or cross-tenant compromise.
EOF

CURRENT_OUTPUT=''
TEST_STATUS=PASS
TEST_REASON=completed
TEST_OBSERVATION=direct
append_cmd() { local label=$1; shift; printf '\n$ %s\n' "$label" >>"$CURRENT_OUTPUT"; "$@" >>"$CURRENT_OUTPUT" 2>&1; }
set_blocked() { TEST_STATUS=BLOCKED; TEST_REASON=$1; printf 'BLOCKED: %s\n' "$1" >>"$CURRENT_OUTPUT"; }
set_error() { TEST_STATUS=ERROR; TEST_REASON=$1; printf 'ERROR: %s\n' "$1" >>"$CURRENT_OUTPUT"; }

test_identity() {
  append_cmd 'date -u; id; uname -a' bash -c 'date -u +%FT%TZ; id; uname -a'
  append_cmd 'container and OS identity' bash -c 'test -e /.dockerenv && echo dockerenv=present || echo dockerenv=absent; grep -E "^(PRETTY_NAME|VERSION_ID)=" /etc/os-release 2>/dev/null || true; printf "pid1_comm="; cat /proc/1/comm 2>/dev/null || true'
  append_cmd 'allowlisted runner identification' bash -c 'for n in CI GITHUB_ACTIONS GITHUB_RUN_ID GITHUB_RUN_ATTEMPT RUNNER_NAME RUNNER_OS RUNNER_ARCH RUNNER_ENVIRONMENT ImageOS ImageVersion; do test -n "${!n-}" && printf "%s=%s\n" "$n" "${!n}"; done; true'
}
test_capabilities() {
  append_cmd 'capability masks and optional decode' bash -c 'grep -E "^Cap(Inh|Prm|Eff|Bnd|Amb):" /proc/self/status; if command -v capsh >/dev/null; then capsh --decode="$(awk "/^CapEff:/{print \$2}" /proc/self/status)"; else echo "capsh=unavailable (raw mask retained)"; fi'
}
test_namespaces() {
  append_cmd 'namespace identities and user mappings' bash -c 'for f in /proc/self/ns/*; do printf "%s %s\n" "$(basename "$f")" "$(readlink "$f")"; done; printf "uid_map="; tr "\n" ";" </proc/self/uid_map; echo; printf "gid_map="; tr "\n" ";" </proc/self/gid_map; echo'
}
test_lsm() {
  append_cmd 'seccomp, AppArmor and user namespace controls' bash -c 'grep -E "^(NoNewPrivs|Seccomp|Seccomp_filters):" /proc/self/status; for p in /proc/self/attr/current /proc/1/attr/current /proc/sys/kernel/unprivileged_userns_clone /proc/sys/user/max_user_namespaces; do if test -r "$p"; then printf "%s=" "$p"; cat "$p"; else printf "%s=unavailable\n" "$p"; fi; done'
}
test_block_devices() {
  append_cmd 'block-device node metadata' bash -c 'found=false; for p in /dev/sd* /dev/nvme* /dev/vd* /dev/xvd*; do test -e "$p" || continue; found=true; stat -c "%F mode=%a owner=%u:%g major_minor=%t:%T path=%n" "$p"; done; $found || echo matching_device_nodes=none'
  if command -v lsblk >/dev/null; then append_cmd 'lsblk topology' bash -c 'lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS | sed -E "s/by-uuid-[^ ]+/by-uuid-<redacted>/g"'; else printf 'lsblk=unavailable\n' >>"$CURRENT_OUTPUT"; fi
}
test_mounts() {
  if command -v findmnt >/dev/null; then
    append_cmd 'mount topology, metadata only' bash -c 'findmnt -rn -o TARGET,SOURCE,FSTYPE,OPTIONS | awk '\''{print $1, $2, $3, (($4 ~ /(^|,)ro(,|$)/) ? "ro" : "rw")}'\'' | head -n 200 | sed -E "s#(/docker/overlay2/)[0-9a-f]{16,}#\1<id>#g; s#(/run/docker/netns/)[0-9a-f]{8,}#\1<id>#g; s/by-uuid-[^ ]+/by-uuid-<redacted>/g"'
  else append_cmd 'mountinfo fallback' bash -c 'head -n 200 /proc/self/mountinfo'; fi
  append_cmd 'root filesystem identity' stat -f -c 'path=/ fs_type=%T fs_id=%i block_size=%S' /
}
need_node() { command -v node >/dev/null 2>&1 || { set_blocked 'Node.js is unavailable'; return 1; }; }
need_socket() {
  [[ -S $SOCK ]] || { set_blocked "Docker socket unavailable at $SOCK"; return 1; }
  [[ -r $SOCK && -w $SOCK ]] || { set_blocked "Docker socket exists but current uid cannot read/write it: $SOCK"; return 1; }
}
docker_call() {
  local mode=$1
  printf '\n$ embedded Node Docker API: %s\n' "$mode" >>"$CURRENT_OUTPUT"
  DOCKER_SOCK="$SOCK" RBA_RUN_ID="$RUN_ID" RBA_TEST_IMAGE="$TEST_IMAGE" RBA_LAB_HOST_PATH="${RBA_LAB_HOST_PATH:-/tmp}" node "$HELPER" "$mode" >>"$CURRENT_OUTPUT" 2>&1
}
test_docker_access() { need_node && need_socket || return 0; docker_call probe || set_error 'Docker daemon probe failed'; }
test_docker_inventory() { need_node && need_socket || return 0; docker_call containers || set_error 'Sanitised Docker inventory failed'; }
test_docker_lifecycle() { need_node && need_socket || return 0; docker_call lifecycle || set_error 'Docker lifecycle/exec/output/cleanup failed'; }
test_scratch() { need_node && need_socket || return 0; docker_call scratch || set_error 'Scratch write/read/delete assertion failed'; }
test_namespace_compare() { need_node && need_socket || return 0; docker_call namespace-compare || set_error 'Namespace comparison failed'; }
test_host_mount() { need_node && need_socket || return 0; docker_call host-mount || set_error 'Read-only host mount assessment failed'; }
test_host_write() { need_node && need_socket || return 0; docker_call host-write || set_error 'Controlled host write assessment failed'; }
test_host_namespace() { need_node && need_socket || return 0; docker_call host-namespace || set_error 'Controlled host namespace execution failed'; }
test_oidc() {
  local n pair=true
  for n in ACTIONS_ID_TOKEN_REQUEST_URL ACTIONS_ID_TOKEN_REQUEST_TOKEN; do
    if [[ -n ${!n-} ]]; then printf '%s=present\n' "$n"; else printf '%s=absent\n' "$n"; pair=false; fi
  done >>"$CURRENT_OUTPUT"
  printf 'oidc_pair_present=%s\nNo token was requested and no value was recorded.\n' "$pair" >>"$CURRENT_OUTPUT"
}
test_lifecycle() {
  TEST_OBSERVATION=direct-and-inferred
  append_cmd 'runner and kernel lifecycle evidence' bash -c 'printf "boot_id="; cat /proc/sys/kernel/random/boot_id 2>/dev/null || echo unavailable; printf "uptime_seconds="; cut -d" " -f1 /proc/uptime 2>/dev/null || echo unavailable; printf "kernel="; uname -r; printf "cgroup="; sed -n "1,20p" /proc/self/cgroup; printf "pid1_start_ticks="; awk "{print \$22}" /proc/1/stat 2>/dev/null || echo unavailable'
  printf 'inference=These values correlate this run only; they do not prove VM destruction, cross-job persistence, or runner reuse.\n' >>"$CURRENT_OUTPUT"
}

TEST_IDS=(identity capabilities namespaces lsm block_devices mounts docker_access docker_inventory docker_lifecycle scratch namespace_compare host_mount host_write host_namespace oidc lifecycle)
declare -A TEST_NAMES TEST_FUNCS TEST_POLICY TEST_PREREQS
TEST_NAMES[identity]='Container identity and runner identification'; TEST_FUNCS[identity]=test_identity
TEST_NAMES[capabilities]='Linux capability configuration'; TEST_FUNCS[capabilities]=test_capabilities
TEST_NAMES[namespaces]='Container namespace isolation'; TEST_FUNCS[namespaces]=test_namespaces
TEST_NAMES[lsm]='Seccomp, AppArmor and user namespace configuration'; TEST_FUNCS[lsm]=test_lsm
TEST_NAMES[block_devices]='Block-device exposure'; TEST_FUNCS[block_devices]=test_block_devices
TEST_NAMES[mounts]='Filesystem and mount topology'; TEST_FUNCS[mounts]=test_mounts
TEST_NAMES[docker_access]='Docker daemon access'; TEST_FUNCS[docker_access]=test_docker_access
TEST_NAMES[docker_inventory]='Sanitised Docker container inventory'; TEST_FUNCS[docker_inventory]=test_docker_inventory
TEST_NAMES[docker_lifecycle]='Docker API container lifecycle and command output'; TEST_FUNCS[docker_lifecycle]=test_docker_lifecycle
TEST_NAMES[scratch]='Isolated scratch filesystem write/read verification'; TEST_FUNCS[scratch]=test_scratch
TEST_NAMES[namespace_compare]='Host-versus-container namespace comparison'; TEST_FUNCS[namespace_compare]=test_namespace_compare
TEST_NAMES[host_mount]='Host filesystem mount eligibility and identification'; TEST_FUNCS[host_mount]=test_host_mount; TEST_POLICY[host_mount]=lab
TEST_NAMES[host_write]='Host filesystem write-permission assessment'; TEST_FUNCS[host_write]=test_host_write; TEST_POLICY[host_write]=lab_authorized
TEST_NAMES[host_namespace]='Host namespace execution validation'; TEST_FUNCS[host_namespace]=test_host_namespace; TEST_POLICY[host_namespace]=lab_authorized
TEST_NAMES[oidc]='GitHub OIDC capability presence'; TEST_FUNCS[oidc]=test_oidc
TEST_NAMES[lifecycle]='Runner and host lifecycle evidence'; TEST_FUNCS[lifecycle]=test_lifecycle
for id in "${TEST_IDS[@]}"; do TEST_POLICY[$id]=${TEST_POLICY[$id]:-all}; done
TEST_PREREQS[identity]='procfs and OS metadata'
TEST_PREREQS[capabilities]='readable /proc/self/status'
TEST_PREREQS[namespaces]='procfs namespace links and uid/gid maps'
TEST_PREREQS[lsm]='procfs security attributes where exposed'
TEST_PREREQS[block_devices]='/dev metadata; lsblk optional'
TEST_PREREQS[mounts]='findmnt optional; mountinfo fallback'
TEST_PREREQS[docker_access]='Node.js and accessible Docker Unix socket'
TEST_PREREQS[docker_inventory]='Docker API access'
TEST_PREREQS[docker_lifecycle]='Docker API and locally available test image'
TEST_PREREQS[scratch]='Docker lifecycle and shell in test image'
TEST_PREREQS[namespace_compare]='Docker permission for PidMode=host'
TEST_PREREQS[host_mount]='lab profile, Docker API and local image'
TEST_PREREQS[host_write]='lab authorization and writable RBA_LAB_HOST_PATH'
TEST_PREREQS[host_namespace]='lab authorization, rootful Docker, privileged permission, nsenter'
TEST_PREREQS[oidc]='none; presence only'
TEST_PREREQS[lifecycle]='readable procfs'

write_result() {
  RBA_RESULTS="$RESULTS_NDJSON" RBA_ID="$1" RBA_NAME="$2" RBA_STARTED="$3" RBA_ENDED="$4" RBA_DURATION="$5" RBA_STATUS="$6" RBA_REASON="$7" RBA_PREREQ="$8" RBA_OBSERVATION="$9" RBA_OUTPUT="${10}" node - <<'NODE'
const fs=require('fs');
const result={id:process.env.RBA_ID,name:process.env.RBA_NAME,status:process.env.RBA_STATUS,reason:process.env.RBA_REASON,startedUTC:process.env.RBA_STARTED,endedUTC:process.env.RBA_ENDED,durationMs:Number(process.env.RBA_DURATION),prerequisites:process.env.RBA_PREREQ,observationType:process.env.RBA_OBSERVATION,observedOutcome:fs.readFileSync(process.env.RBA_OUTPUT,'utf8').slice(0,65536)};
fs.appendFileSync(process.env.RBA_RESULTS,JSON.stringify(result)+'\n',{mode:0o600});
NODE
}
run_test() {
  local id=$1 name=${TEST_NAMES[$1]} policy=${TEST_POLICY[$1]} prereq=${TEST_PREREQS[$1]}
  local start_ms end_ms started ended rc=0
  CURRENT_OUTPUT="$BASE/test-$id.txt"; : >"$CURRENT_OUTPUT"
  TEST_STATUS=PASS; TEST_REASON=completed; TEST_OBSERVATION=direct
  started=$(date -u +%FT%T.%3NZ); start_ms=$(date +%s%3N)
  if [[ $policy == lab && $PROFILE != lab ]]; then
    TEST_STATUS=SKIPPED; TEST_REASON='hosted policy prohibits host filesystem bind mounts'; TEST_OBSERVATION=unexecuted-policy
    printf 'SKIPPED: %s\n' "$TEST_REASON" >"$CURRENT_OUTPUT"
  elif [[ $policy == lab_authorized && $PROFILE != lab ]]; then
    TEST_STATUS=SKIPPED; TEST_REASON='hosted policy prohibits host mutation or host namespace execution'; TEST_OBSERVATION=unexecuted-policy
    printf 'SKIPPED: %s\n' "$TEST_REASON" >"$CURRENT_OUTPUT"
  elif [[ $policy == lab_authorized && $LAB_AUTHORIZED != true ]]; then
    TEST_STATUS=BLOCKED; TEST_REASON='lab profile lacks --authorize-lab'; TEST_OBSERVATION=unexecuted-authorization
    printf 'BLOCKED: %s\n' "$TEST_REASON" >"$CURRENT_OUTPUT"
  else
    "${TEST_FUNCS[$id]}" || rc=$?
    if ((rc != 0)) && [[ $TEST_STATUS == PASS ]]; then TEST_STATUS=ERROR; TEST_REASON="test function exited $rc"; fi
  fi
  ended=$(date -u +%FT%T.%3NZ); end_ms=$(date +%s%3N)
  {
    printf '\n===== TEST %s: %s =====\n' "$id" "$name"
    printf 'Status: %s\nReason: %s\nPrerequisites: %s\nObservation type: %s\nStarted: %s\nEnded: %s\nDuration ms: %s\n' "$TEST_STATUS" "$TEST_REASON" "$prereq" "$TEST_OBSERVATION" "$started" "$ended" "$((end_ms-start_ms))"
    cat "$CURRENT_OUTPUT"
  } | tee -a "$REPORT"
  write_result "$id" "$name" "$started" "$ended" "$((end_ms-start_ms))" "$TEST_STATUS" "$TEST_REASON" "$prereq" "$TEST_OBSERVATION" "$CURRENT_OUTPUT"
}
cleanup_run() {
  command -v node >/dev/null 2>&1 && [[ -S $SOCK ]] || return 0
  DOCKER_SOCK="$SOCK" RBA_RUN_ID="$RUN_ID" node "$HELPER" cleanup-run >/dev/null 2>&1 || printf 'WARNING: cleanup sweep failed\n' >&2
}
on_signal() { printf '\nINTERRUPTED at %s; cleanup initiated.\n' "$(date -u +%FT%TZ)" | tee -a "$REPORT"; cleanup_run; trap - EXIT; exit 130; }
trap on_signal INT TERM HUP
trap cleanup_run EXIT

create_environment() {
  RBA_ENV_OUT="$ENVIRONMENT" RBA_VERSION="$VERSION" RBA_RUN_ID="$RUN_ID" RBA_PROFILE="$PROFILE" RBA_SOCK="$SOCK" node - <<'NODE'
const fs=require('fs'),os=require('os');const allow=['CI','GITHUB_ACTIONS','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','RUNNER_NAME','RUNNER_OS','RUNNER_ARCH','RUNNER_ENVIRONMENT','ImageOS','ImageVersion'];const runner={};for(const key of allow)if(process.env[key])runner[key]=process.env[key];const data={schemaVersion:3,toolVersion:process.env.RBA_VERSION,runId:process.env.RBA_RUN_ID,profile:process.env.RBA_PROFILE,generatedUTC:new Date().toISOString(),runtime:{node:process.version,platform:process.platform,arch:process.arch,kernel:os.release(),hostname:os.hostname()},runner:runner,dockerSocketPath:process.env.RBA_SOCK,redactionPolicy:'Allowlisted runner identifiers and sanitised observations only.'};fs.writeFileSync(process.env.RBA_ENV_OUT,JSON.stringify(data,null,2)+'\n',{mode:0o600});
NODE
}
finalize_json() {
  RBA_NDJSON="$RESULTS_NDJSON" RBA_SUMMARY="$SUMMARY" RBA_ENV_OUT="$ENVIRONMENT" node - <<'NODE'
const fs=require('fs'),environment=JSON.parse(fs.readFileSync(process.env.RBA_ENV_OUT));const text=fs.readFileSync(process.env.RBA_NDJSON,'utf8').trim();const results=text?text.split('\n').map(JSON.parse):[];const counts={PASS:0,FAIL:0,BLOCKED:0,SKIPPED:0,ERROR:0};for(const result of results)counts[result.status]=(counts[result.status]||0)+1;const interpretation={containerRoot:'Does not by itself prove runner-host control.',runnerHostControl:'Requires a distinct host-boundary observation.',hostNamespaceExecution:'Does not prove access outside the allocated runner VM.',crossTenantCompromise:'Not tested; no result proves cross-runner or cross-tenant access.'};fs.writeFileSync(process.env.RBA_SUMMARY,JSON.stringify({schemaVersion:3,generatedUTC:new Date().toISOString(),environment:environment,counts:counts,results:results,interpretation:interpretation},null,2)+'\n',{mode:0o600});
NODE
}
bundle() {
  finalize_json
  printf '\nEvidence finalised UTC: %s\n' "$(date -u +%FT%TZ)" >>"$REPORT"
  (cd "$BASE" && sha256sum evidence.txt results.ndjson results.json environment.json docker-api-client.js test-*.txt >SHA256SUMS)
  local parent name; parent=$(dirname "$BASE"); name=$(basename "$BASE"); ARCHIVE="$parent/${name}.tar.gz"
  command -v tar >/dev/null || { echo 'GNU tar unavailable' >&2; return 1; }
  tar --version | head -n1 | grep -q 'GNU tar' || { echo 'GNU tar required' >&2; return 1; }
  (cd "$BASE" && tar --sort=name --owner=0 --group=0 --numeric-owner -czf "$ARCHIVE" evidence.txt results.ndjson results.json environment.json docker-api-client.js SHA256SUMS test-*.txt)
  printf '\nEvidence directory: %s\nArchive: %s\nSHA256: %s\n' "$BASE" "$ARCHIVE" "$(sha256sum "$ARCHIVE" | awk '{print $1}')"
}
upload() {
  [[ $DO_UPLOAD == true ]] || return 0
  command -v curl >/dev/null || { echo 'curl unavailable' >&2; return 1; }
  [[ $UPLOAD_ENDPOINT == https://ul.sto.care || $UPLOAD_ENDPOINT == https://ul.sto.care/ ]] || { echo 'Upload endpoint must be https://ul.sto.care' >&2; return 1; }
  local response status url hash; response=$(mktemp); hash=$(sha256sum "$ARCHIVE" | awk '{print $1}')
  status=$(curl --silent --show-error --max-time 120 -o "$response" -w '%{http_code}' -F "file=@${ARCHIVE};type=application/gzip" "$UPLOAD_ENDPOINT") || { rm -f "$response"; echo 'Upload request failed' >&2; return 1; }
  [[ $status =~ ^2[0-9][0-9]$ ]] || { printf 'Upload HTTP %s: ' "$status" >&2; head -c 300 "$response" >&2; echo >&2; rm -f "$response"; return 1; }
  url=$(node - "$response" <<'NODE'
const fs=require('fs'),body=fs.readFileSync(process.argv[2],'utf8');let candidates=[];try{const value=JSON.parse(body);for(const item of [value.url,value.link,value.download_url,value.data&&value.data.url])if(typeof item==='string')candidates.push(item)}catch(_){}candidates.push(...(body.match(/https:\/\/[^\s"'<>]+/g)||[]));const found=candidates.find(function(item){try{const parsed=new URL(item);return parsed.protocol==='https:'&&(parsed.hostname==='ul.sto.care'||parsed.hostname.endsWith('.sto.care'))}catch(_){return false}});if(found)process.stdout.write(found);
NODE
  ); rm -f "$response"
  [[ -n $url ]] || { echo 'Upload succeeded but returned no validated sto.care URL' >&2; return 1; }
  printf 'Uploaded file URL: %s\nSHA256: %s\n' "$url" "$hash"
}
run_all() { create_environment; for id in "${TEST_IDS[@]}"; do run_test "$id"; done; bundle; upload; }

if [[ $DO_ALL == true ]]; then run_all; exit $?; fi
create_environment
while :; do
  printf '\n=== Runner Boundary Audit v%s (%s) ===\n1 Run all tests\n2 List registry\n3 Run one registered test\n4 Bundle\n5 Upload current bundle (requires --upload)\n0 Exit\nChoice: ' "$VERSION" "$PROFILE"
  read -r choice || break
  case $choice in
    1) for id in "${TEST_IDS[@]}"; do run_test "$id"; done ;;
    2) for id in "${TEST_IDS[@]}"; do printf '%-20s %-14s %s\n' "$id" "${TEST_POLICY[$id]}" "${TEST_NAMES[$id]}"; done ;;
    3)
      printf 'Test id: '; read -r wanted
      if [[ -n ${TEST_NAMES[$wanted]+present} ]]; then run_test "$wanted"; else echo 'Unknown test id'; fi
      ;;
    4) bundle ;;
    5)
      if [[ $DO_UPLOAD == true ]]; then upload; else echo 'Upload disabled: relaunch with --upload.'; fi
      ;;
    0) break ;;
    *) echo 'Invalid choice' ;;
  esac
done
printf 'Evidence directory: %s\n' "$BASE"
