# Changelog

## 3.0.0

- Replaced the implicit function sequence with a 16-entry test registry.
- Added hosted and lab profiles with explicit SKIPPED/BLOCKED policy results.
- Added per-test timestamps, duration, prerequisites, observation type, outcome, and terminal status.
- Expanded the Node Docker API client with version negotiation, inventory, inspection, create/start/exec/output capture, and run-labelled cleanup.
- Added constrained lifecycle and private tmpfs write/read/delete tests.
- Added host PID namespace comparison without collecting process details.
- Added lab-only read-only host-root identification, controlled host write/read/delete, and privileged host namespace validation.
- Added allowlisted environment metadata, structured JSON/NDJSON, per-test evidence, SHA-256 manifest, and normalized GNU tar packaging.
- Hardened upload to require --upload, multipart field file, 2xx status, and a validated HTTPS sto.care response URL.
- Added signal cleanup, exact-run cleanup sweeps, utility detection, documentation, automated tests, and sample evidence.
- Corrected v2.2's text-search-derived summary, hard-coded Docker API assumptions, detached exec without output capture, and prose-only host-boundary placeholders.

The original v2.2 implementation is retained as legacy-v2.2.sh for review provenance.
